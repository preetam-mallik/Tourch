package com.preitam.touchcontrol;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.SeekBar;
import android.widget.Toast;
import android.view.Gravity;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private TextView status, countText, sensitivityText;
    private TouchPad touchPad;
    private boolean testEnabled = true;
    private int sensitivityValue = 50;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView label(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(Color.rgb(30, 41, 59));
        return t;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(16));
        root.setBackgroundColor(Color.rgb(246, 248, 251));

        TextView title = label("Touch Control", 27);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = label("Touch tester • Android 10 • No root", 14);
        subtitle.setTextColor(Color.rgb(100, 116, 139));
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.topMargin = dp(4);
        root.addView(subtitle, subParams);

        status = label("Touch test: ON", 16);
        status.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = dp(20);
        root.addView(status, statusParams);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button toggle = button("Turn test ON / OFF");
        toggle.setOnClickListener(v -> {
            testEnabled = !testEnabled;
            status.setText("Touch test: " + (testEnabled ? "ON" : "OFF"));
            touchPad.invalidate();
            Toast.makeText(this, testEnabled ? "Touch test enabled" : "Touch test paused",
                    Toast.LENGTH_SHORT).show();
        });
        actions.addView(toggle, new LinearLayout.LayoutParams(0, dp(52), 1));

        Button reset = button("Reset");
        reset.setOnClickListener(v -> {
            touchPad.reset();
            updateCount();
        });
        LinearLayout.LayoutParams resetParams = new LinearLayout.LayoutParams(0, dp(52), 1);
        resetParams.leftMargin = dp(8);
        actions.addView(reset, resetParams);
        LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(-1, -2);
        actionParams.topMargin = dp(8);
        root.addView(actions, actionParams);

        countText = label("Touch points: 0", 15);
        LinearLayout.LayoutParams countParams = new LinearLayout.LayoutParams(-1, -2);
        countParams.topMargin = dp(14);
        root.addView(countText, countParams);

        touchPad = new TouchPad();
        LinearLayout.LayoutParams padParams = new LinearLayout.LayoutParams(-1, 0, 1);
        padParams.topMargin = dp(10);
        padParams.bottomMargin = dp(12);
        root.addView(touchPad, padParams);

        TextView sensitivityTitle = label("Sensitivity level (visual setting only)", 15);
        sensitivityTitle.setTypeface(null, Typeface.BOLD);
        root.addView(sensitivityTitle);

        sensitivityText = label("Level: 50 / 100", 14);
        LinearLayout.LayoutParams sensTextParams = new LinearLayout.LayoutParams(-1, -2);
        sensTextParams.topMargin = dp(4);
        root.addView(sensitivityText, sensTextParams);

        SeekBar seek = new SeekBar(this);
        seek.setMax(100);
        seek.setProgress(sensitivityValue);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int value, boolean user) {
                sensitivityValue = value;
                sensitivityText.setText("Level: " + value + " / 100 (does not change system sensitivity)");
            }
            public void onStartTrackingTouch(SeekBar bar) {}
            public void onStopTrackingTouch(SeekBar bar) {}
        });
        root.addView(seek, new LinearLayout.LayoutParams(-1, dp(42)));

        Button settings = button("Open Android Settings");
        settings.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception e) {
                Toast.makeText(this, "Settings app could not be opened", Toast.LENGTH_SHORT).show();
            }
        });
        LinearLayout.LayoutParams settingsParams = new LinearLayout.LayoutParams(-1, dp(50));
        settingsParams.topMargin = dp(6);
        root.addView(settings, settingsParams);

        TextView note = label("Note: Android does not expose a universal touch-sensitivity API to regular apps. Use your phone's own settings if a touch-related option is available.", 12);
        note.setTextColor(Color.rgb(100, 116, 139));
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(-1, -2);
        noteParams.topMargin = dp(8);
        root.addView(note, noteParams);

        setContentView(root);
    }

    private void updateCount() {
        countText.setText("Touch points: " + touchPad.getTouchCount());
    }

    private class TouchPad extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int touchCount = 0;
        private float x = -1, y = -1;
        private String message = "Touch here to test";
        TouchPad() { super(MainActivity.this); setBackground(bg(Color.WHITE, 18)); }
        int getTouchCount() { return touchCount; }
        void reset() { touchCount = 0; x = y = -1; message = "Touch here to test"; invalidate(); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            paint.setColor(testEnabled ? Color.rgb(15, 118, 110) : Color.GRAY);
            paint.setTextSize(dp(17));
            paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            c.drawText(testEnabled ? message : "Touch test paused", dp(16), dp(30), paint);
            paint.setTextSize(dp(13));
            paint.setTypeface(Typeface.DEFAULT);
            paint.setColor(Color.rgb(100, 116, 139));
            c.drawText("Drag your finger around this area", dp(16), dp(54), paint);
            if (x >= 0 && y >= 0) {
                paint.setColor(Color.rgb(59, 130, 246));
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(dp(2));
                c.drawCircle(x, y, dp(18), paint);
                paint.setStyle(Paint.Style.FILL);
                c.drawCircle(x, y, dp(4), paint);
            }
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (!testEnabled) return true;
            int action = e.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE ||
                action == MotionEvent.ACTION_POINTER_DOWN) {
                x = e.getX();
                y = e.getY();
                if (action != MotionEvent.ACTION_MOVE) {
                    touchCount++;
                    updateCount();
                }
                message = "Touch detected ✓";
                invalidate();
                return true;
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                x = e.getX(); y = e.getY();
                invalidate();
                return true;
            }
            return true;
        }
    }
}
