# Touch Control — Android Studio Source Project

## Features
- Touch test area: finger tap/drag detection and visual marker
- Touch test ON/OFF (this only pauses/resumes the in-app tester)
- Reset touch counter
- Sensitivity slider UI (demonstration only; does not modify Android's actual touchscreen sensitivity)
- Button to open Android Settings
- No root and no special permissions

## Important limitation
Normal third-party Android apps cannot universally increase/decrease touchscreen hardware sensitivity or toggle the phone's touchscreen globally. This project deliberately does not claim to do that. If your MIUI build provides a touch-related option, check Settings; available options vary by device/ROM.

## Open and build
1. Download and extract the ZIP.
2. Open Android Studio.
3. Choose **Open**, then select the extracted `TouchControlAndroidStudio` folder.
4. Let Gradle sync. Use JDK 17 with Android Gradle Plugin 8.6.1.
5. Connect the Redmi 9i with USB debugging enabled, or use an Android 10 emulator.
6. Press **Run** to install.

To create an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
The debug APK is usually generated at:
`app/build/outputs/apk/debug/app-debug.apk`

## Compatibility
- minSdk 23 (Android 6+)
- targetSdk 29
- Designed for Android 10 / Redmi 9i, but not tested on physical hardware here.
